<?php
function enqueue_custom_styles_and_scripts() {
    // Enqueue stylesheets
    wp_enqueue_style('bootstrap', get_template_directory_uri() . '/assets/css/bootstrap.min.css');
    wp_enqueue_style('animate', get_template_directory_uri() . '/assets/css/animate.min.css');
    wp_enqueue_style('magnific-popup', get_template_directory_uri() . '/assets/css/magnific-popup.css');
    // Enqueue other stylesheets...

    // Enqueue scripts
    wp_enqueue_script('jquery', get_template_directory_uri() . '/assets/js/vendor/jquery-3.6.0.min.js', array(), null, true);
    wp_enqueue_script('bootstrap-bundle', get_template_directory_uri() . '/assets/js/bootstrap.bundle.min.js', array('jquery'), null, true);
    wp_enqueue_script('magnific-popup', get_template_directory_uri() . '/assets/js/jquery.magnific-popup.min.js', array('jquery'), null, true);
    // Enqueue other scripts...
    
    // Inline script
    wp_add_inline_script( 'main', 'function rangeSlide(value) {
        document.getElementById("rangeValue").innerHTML = value;
    }', 'after' );
}
add_action('wp_enqueue_scripts', 'enqueue_custom_styles_and_scripts');

// Append scripts before </body> tag
function append_scripts_before_body_tag() {
    // Enqueue scripts
    wp_enqueue_script('odometer', get_template_directory_uri() . '/assets/js/jquery.odometer.min.js', array('jquery'), null, true);
    wp_enqueue_script('appear', get_template_directory_uri() . '/assets/js/jquery.appear.js', array('jquery'), null, true);
    wp_enqueue_script('gsap', get_template_directory_uri() . '/assets/js/gsap.js', array(), null, true);
    // Enqueue other scripts...
    wp_enqueue_script('your-script', get_template_directory_uri() . '/assets/js/your-script.js', array(), null, true);
}
add_action('wp_footer', 'append_scripts_before_body_tag');
